export default {
  data () {
    return {
      prefix: 'drag-drawer'
    }
  }
}
